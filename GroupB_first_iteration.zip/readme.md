To run the project 

python -m venv venv
venv\Scripts\activate 
pip install -r requirements.txt
cd main
py manage.py runserver 

add /admin to the link to access admin portal 
username : admin
password : adminpassword 

add /student to the link to access student portal 
use institute email id (a student email id if possible) to access the student portal 

git repo :  https://github.com/Naren-Sai-17/iiti_fee_portal
